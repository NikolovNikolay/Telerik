-- phpMyAdmin SQL Dump
-- version 4.0.4.1
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: Oct 25, 2013 at 12:29 PM
-- Server version: 5.5.32
-- PHP Version: 5.4.19

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `books_authors_comments`
--
CREATE DATABASE IF NOT EXISTS `books_authors_comments` DEFAULT CHARACTER SET utf8 COLLATE utf8_general_ci;
USE `books_authors_comments`;

-- --------------------------------------------------------

--
-- Table structure for table `authors`
--

CREATE TABLE IF NOT EXISTS `authors` (
  `author_id` int(11) NOT NULL AUTO_INCREMENT,
  `author_name` varchar(250) NOT NULL,
  PRIMARY KEY (`author_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=7 ;

--
-- Dumping data for table `authors`
--

INSERT INTO `authors` (`author_id`, `author_name`) VALUES
(1, 'Николай Хайтов'),
(2, 'Тери Пратчет'),
(3, 'Виктор Юго'),
(4, 'Пенчо Славейков'),
(5, 'Е. Л. Джеймс'),
(6, 'Дж. Р. Толкин');

-- --------------------------------------------------------

--
-- Table structure for table `books`
--

CREATE TABLE IF NOT EXISTS `books` (
  `book_id` int(11) NOT NULL AUTO_INCREMENT,
  `book_title` varchar(250) NOT NULL,
  PRIMARY KEY (`book_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=8 ;

--
-- Dumping data for table `books`
--

INSERT INTO `books` (`book_id`, `book_title`) VALUES
(1, 'Fifty shades of gay'),
(2, 'Клетниците'),
(3, 'Бай Ганьо'),
(4, 'Дервишово семе'),
(5, 'тест'),
(6, 'Още един тест'),
(7, 'Хобитът');

-- --------------------------------------------------------

--
-- Table structure for table `books_authors`
--

CREATE TABLE IF NOT EXISTS `books_authors` (
  `book_id` int(11) NOT NULL,
  `author_id` int(11) NOT NULL,
  KEY `book_id` (`book_id`),
  KEY `author_id` (`author_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `books_authors`
--

INSERT INTO `books_authors` (`book_id`, `author_id`) VALUES
(1, 5),
(2, 3),
(3, 4),
(4, 1),
(5, 1),
(5, 2),
(5, 3),
(6, 1),
(6, 2),
(6, 3),
(6, 4),
(6, 5),
(7, 6);

-- --------------------------------------------------------

--
-- Table structure for table `messages`
--

CREATE TABLE IF NOT EXISTS `messages` (
  `message_id` int(11) NOT NULL AUTO_INCREMENT,
  `user` varchar(250) NOT NULL,
  `message` varchar(250) NOT NULL,
  `about_book` varchar(250) NOT NULL,
  `date` datetime NOT NULL,
  PRIMARY KEY (`message_id`),
  KEY `about_book` (`about_book`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=10 ;

--
-- Dumping data for table `messages`
--

INSERT INTO `messages` (`message_id`, `user`, `message`, `about_book`, `date`) VALUES
(1, 'user', 'gfbgb', 'Бай Ганьо', '2013-10-19 19:30:53'),
(2, 'user', 'Не е лоша да', 'Бай Ганьо', '2013-10-19 19:57:17'),
(3, 'ivanov', 'Абсолютна боза', 'Fifty shades of gay', '2013-10-19 19:59:34'),
(4, 'ivanov', 'тестченцееее', 'Още един тест', '2013-10-19 19:59:52'),
(5, 'petrov', 'тествама пак', 'Клетниците', '2013-10-19 20:00:25'),
(6, 'petrov', 'ии пак', 'Клетниците', '2013-10-19 20:00:31'),
(7, 'petrov', 'Приятно четиво', 'Fifty shades of gay', '2013-10-19 20:02:52'),
(8, 'petrov', 'ала bala', 'Fifty shades of gay', '2013-10-19 21:04:09'),
(9, 'user', 'Гледал съм филма, малко аз!', 'Клетниците', '2013-10-25 11:05:23');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE IF NOT EXISTS `users` (
  `user_id` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(250) NOT NULL,
  `userpass` varchar(250) NOT NULL,
  PRIMARY KEY (`user_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=4 ;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`user_id`, `username`, `userpass`) VALUES
(1, 'user', 'qwerty'),
(2, 'petrov', 'petrov'),
(3, 'ivanov', 'ivanov');

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
